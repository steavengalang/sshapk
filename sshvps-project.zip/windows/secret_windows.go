//go:build windows

package main

import (
	"encoding/base64"
	"strings"
	"syscall"
	"unsafe"
)

var (
	crypt32            = syscall.NewLazyDLL("crypt32.dll")
	kernel32Sec        = syscall.NewLazyDLL("kernel32.dll")
	procProtectData    = crypt32.NewProc("CryptProtectData")
	procUnprotectData  = crypt32.NewProc("CryptUnprotectData")
	procLocalFreeSec   = kernel32Sec.NewProc("LocalFree")
	secretPrefixDPAPI  = "dpapi:"
	secretPrefixPlainT = "plain:"
)

type dataBlob struct {
	cbData uint32
	pbData *byte
}

func newBlob(b []byte) dataBlob {
	if len(b) == 0 {
		return dataBlob{}
	}
	return dataBlob{cbData: uint32(len(b)), pbData: &b[0]}
}

func (b dataBlob) bytes() []byte {
	if b.cbData == 0 || b.pbData == nil {
		return nil
	}
	out := make([]byte, b.cbData)
	copy(out, unsafe.Slice(b.pbData, b.cbData))
	return out
}

// encryptSecret mengenkripsi password memakai DPAPI (terikat ke akun Windows user).
// File config yang dicuri ke komputer lain tidak bisa dibaca.
func encryptSecret(plain string) string {
	if plain == "" {
		return ""
	}
	in := newBlob([]byte(plain))
	var out dataBlob
	r, _, _ := procProtectData.Call(
		uintptr(unsafe.Pointer(&in)), 0, 0, 0, 0, 0,
		uintptr(unsafe.Pointer(&out)),
	)
	if r == 0 {
		return secretPrefixPlainT + base64.StdEncoding.EncodeToString([]byte(plain))
	}
	defer procLocalFreeSec.Call(uintptr(unsafe.Pointer(out.pbData)))
	return secretPrefixDPAPI + base64.StdEncoding.EncodeToString(out.bytes())
}

func decryptSecret(stored string) string {
	switch {
	case stored == "":
		return ""
	case strings.HasPrefix(stored, secretPrefixPlainT):
		b, _ := base64.StdEncoding.DecodeString(strings.TrimPrefix(stored, secretPrefixPlainT))
		return string(b)
	case strings.HasPrefix(stored, secretPrefixDPAPI):
		raw, err := base64.StdEncoding.DecodeString(strings.TrimPrefix(stored, secretPrefixDPAPI))
		if err != nil {
			return ""
		}
		in := newBlob(raw)
		var out dataBlob
		r, _, _ := procUnprotectData.Call(
			uintptr(unsafe.Pointer(&in)), 0, 0, 0, 0, 0,
			uintptr(unsafe.Pointer(&out)),
		)
		if r == 0 {
			return ""
		}
		defer procLocalFreeSec.Call(uintptr(unsafe.Pointer(out.pbData)))
		return string(out.bytes())
	default:
		// config lama / diedit manual: anggap plaintext
		return stored
	}
}

package com.chill.sshvps

/**
 * Buffer teks sederhana untuk output shell:
 * - membuang escape-sequence ANSI (warna, posisi kursor, dll)
 * - menangani \r (tulis ulang baris) dan backspace
 * - membatasi jumlah baris supaya tidak boros memori
 */
class TerminalBuffer(private val maxLines: Int = 3000) {

    private val lines = ArrayList<StringBuilder>().apply { add(StringBuilder()) }
    private var col = 0
    private var pendingEscape = StringBuilder()
    private var inEscape = false
    private var escType = 0 // 1 = CSI (ESC[…), 2 = OSC (ESC]…BEL/ST)

    /** Menambahkan potongan output mentah dari server. */
    @Synchronized
    fun append(chunk: String) {
        for (ch in chunk) {
            if (inEscape) {
                pendingEscape.append(ch)
                val done = when (escType) {
                    1 -> ch in '@'..'~'
                    2 -> ch == '\u0007' || ch == '\\'
                    else -> true
                }
                if (escType == 0) {
                    when (ch) {
                        '[' -> escType = 1
                        ']' -> escType = 2
                        else -> { inEscape = false; pendingEscape.clear() }
                    }
                    continue
                }
                if (done) {
                    handleEscape(pendingEscape.toString())
                    inEscape = false
                    escType = 0
                    pendingEscape.clear()
                }
                continue
            }
            when (ch) {
                '\u001B' -> { inEscape = true; escType = 0; pendingEscape.clear() }
                '\r' -> col = 0
                '\n' -> newLine()
                '\b' -> if (col > 0) col--
                '\u0007' -> {} // bel
                '\u000C' -> clear()
                else -> if (ch >= ' ' || ch == '\t') put(ch)
            }
        }
        trim()
    }

    private fun handleEscape(seq: String) {
        // hanya perlu menangani clear-screen; sisanya (warna dsb) dibuang
        if (seq.endsWith("J") && (seq == "[2J" || seq == "[3J")) clear()
        if (seq == "[H" && lines.size == 1) col = 0
    }

    private fun put(ch: Char) {
        val line = lines.last()
        while (line.length < col) line.append(' ')
        if (col < line.length) line.setCharAt(col, ch) else line.append(ch)
        col++
    }

    private fun newLine() {
        lines.add(StringBuilder())
        col = 0
    }

    private fun trim() {
        while (lines.size > maxLines) lines.removeAt(0)
    }

    @Synchronized
    fun clear() {
        lines.clear()
        lines.add(StringBuilder())
        col = 0
    }

    @Synchronized
    fun text(): String = lines.joinToString("\n")

    /** Ambil output setelah baris terakhir yang berisi [marker] (dipakai "copy output terakhir"). */
    @Synchronized
    fun textAfterLastPrompt(marker: String): String {
        if (marker.isBlank()) return text()
        val idx = lines.indexOfLast { it.contains(marker) }
        if (idx < 0) return text()
        return lines.subList(idx, lines.size).joinToString("\n")
    }

    @Synchronized
    fun lineCount(): Int = lines.size
}

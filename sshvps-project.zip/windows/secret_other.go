//go:build !windows

package main

import (
	"encoding/base64"
	"strings"
)

// Di luar Windows tidak ada DPAPI: password hanya di-encode (bukan enkripsi kuat).
func encryptSecret(plain string) string {
	if plain == "" {
		return ""
	}
	return "plain:" + base64.StdEncoding.EncodeToString([]byte(plain))
}

func decryptSecret(stored string) string {
	if stored == "" {
		return ""
	}
	if strings.HasPrefix(stored, "plain:") {
		b, _ := base64.StdEncoding.DecodeString(strings.TrimPrefix(stored, "plain:"))
		return string(b)
	}
	if strings.HasPrefix(stored, "dpapi:") {
		return ""
	}
	return stored
}

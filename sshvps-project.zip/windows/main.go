// sshvps — SSH client sederhana yang otomatis konek ke VPS yang tersimpan.
//
// Pemakaian:
//
//	sshvps                       -> auto-connect ke server default
//	sshvps root@domain.com       -> konek langsung (dan tawarkan simpan)
//	sshvps --add                 -> tambah server baru
//	sshvps --list                -> daftar server tersimpan
//	sshvps --menu                -> pilih server dari daftar
//	sshvps --run "df -h"         -> jalankan satu perintah lalu keluar
package main

import (
	"bufio"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"golang.org/x/crypto/ssh"
)

const version = "1.0.0"

// warna ANSI
const (
	cReset = "\x1b[0m"
	cDim   = "\x1b[2m"
	cBold  = "\x1b[1m"
	cCyan  = "\x1b[36m"
	cGreen = "\x1b[32m"
	cYel   = "\x1b[33m"
	cRed   = "\x1b[31m"
)

var stdin = bufio.NewReader(os.Stdin)

func main() {
	initConsole()
	setConsoleTitle("sshvps")

	cfg, err := loadConfig()
	if err != nil {
		fmt.Printf("%sConfig rusak (%v), pakai config kosong.%s\n", cYel, err, cReset)
	}

	var target, runCmd string
	var forceMenu, forceAdd, listOnly bool
	args := os.Args[1:]
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "--add" || a == "-a":
			forceAdd = true
		case a == "--list" || a == "-l":
			listOnly = true
		case a == "--menu" || a == "-m":
			forceMenu = true
		case a == "--version" || a == "-v":
			fmt.Println("sshvps " + version)
			return
		case a == "--help" || a == "-h" || a == "/?":
			usage()
			return
		case a == "--run" || a == "-r":
			if i+1 < len(args) {
				i++
				runCmd = args[i]
			}
		case a == "--config":
			fmt.Println(cfg.path)
			return
		case strings.HasPrefix(a, "-"):
			fmt.Printf("%sOpsi tidak dikenal: %s%s\n", cYel, a, cReset)
		default:
			target = a
		}
	}

	banner()

	if listOnly {
		listServers(cfg)
		pause()
		return
	}

	var srv *Server
	switch {
	case forceAdd || len(cfg.Servers) == 0 && target == "":
		srv = wizard(cfg)
		if srv == nil {
			return
		}
	case target != "":
		u, h, p := parseTarget(target)
		if existing := cfg.find(h); existing != nil && existing.User == u {
			srv = existing
		} else {
			pw := askPassword(fmt.Sprintf("Password untuk %s@%s: ", u, h))
			srv = &Server{Name: h, Host: h, Port: p, User: u, Password: encryptSecret(pw)}
			if yesNo("Simpan server ini biar lain kali langsung konek?", true) {
				srv.AutoConnect = len(cfg.Servers) == 0
				cfg.Servers = append(cfg.Servers, *srv)
				if err := cfg.save(); err != nil {
					fmt.Printf("%sGagal menyimpan config: %v%s\n", cRed, err, cReset)
				}
				srv = &cfg.Servers[len(cfg.Servers)-1]
			}
		}
	case forceMenu || cfg.autoServer() == nil:
		srv = pickServer(cfg)
		if srv == nil {
			return
		}
	default:
		srv = cfg.autoServer()
	}

	code := run(cfg, srv, runCmd)
	if code != 0 {
		os.Exit(code)
	}
}

func banner() {
	fmt.Printf("%s%s┌───────────────────────────────────────┐%s\n", cBold, cCyan, cReset)
	fmt.Printf("%s%s│  sshvps %-6s  auto-connect ke VPS    │%s\n", cBold, cCyan, version, cReset)
	fmt.Printf("%s%s└───────────────────────────────────────┘%s\n", cBold, cCyan, cReset)
}

func usage() {
	fmt.Print(`
sshvps — auto-connect SSH ke VPS

  sshvps                     konek otomatis ke server default
  sshvps root@domain.com     konek ke alamat tertentu
  sshvps --menu              pilih dari daftar server
  sshvps --add               tambah server baru
  sshvps --list              lihat daftar server
  sshvps --run "df -h"       jalankan 1 perintah lalu keluar
  sshvps --config            tampilkan lokasi file config

Saat sesi berjalan, tekan Ctrl+] untuk membuka menu shortcut perintah.
`)
}

// ---------- interaksi terminal ----------

func ask(prompt, def string) string {
	if def != "" {
		fmt.Printf("%s%s [%s]: %s", cBold, prompt, def, cReset)
	} else {
		fmt.Printf("%s%s: %s", cBold, prompt, cReset)
	}
	line, _ := stdin.ReadString('\n')
	line = strings.TrimSpace(line)
	if line == "" {
		return def
	}
	return line
}

func askPassword(prompt string) string {
	fmt.Printf("%s%s%s", cBold, prompt, cReset)
	restore := echoOff()
	line, _ := stdin.ReadString('\n')
	restore()
	fmt.Println()
	return strings.TrimRight(line, "\r\n")
}

func yesNo(q string, def bool) bool {
	d := "y/N"
	if def {
		d = "Y/n"
	}
	fmt.Printf("%s%s (%s): %s", cBold, q, d, cReset)
	line, _ := stdin.ReadString('\n')
	line = strings.ToLower(strings.TrimSpace(line))
	if line == "" {
		return def
	}
	return line == "y" || line == "ya" || line == "yes"
}

func pause() {
	fmt.Printf("%s\nTekan Enter untuk menutup...%s", cDim, cReset)
	stdin.ReadString('\n')
}

// ---------- manajemen server ----------

func wizard(cfg *Config) *Server {
	fmt.Printf("\n%sSetup server baru%s\n", cBold, cReset)
	fmt.Printf("%sContoh: root@namadomain.com atau root@103.12.34.56:2222%s\n\n", cDim, cReset)

	t := ask("Alamat SSH", "")
	if t == "" {
		fmt.Println("Dibatalkan.")
		return nil
	}
	u, h, p := parseTarget(t)
	name := ask("Nama panggilan server", h)
	pw := askPassword("Password")

	s := Server{Name: name, Host: h, Port: p, User: u, Password: encryptSecret(pw)}
	s.AutoConnect = yesNo("Jadikan server default (langsung konek saat aplikasi dibuka)?", true)
	if s.AutoConnect {
		for i := range cfg.Servers {
			cfg.Servers[i].AutoConnect = false
		}
	}
	cfg.Servers = append(cfg.Servers, s)
	if err := cfg.save(); err != nil {
		fmt.Printf("%sGagal menyimpan config: %v%s\n", cRed, err, cReset)
	} else {
		fmt.Printf("%sTersimpan di %s%s\n", cGreen, cfg.path, cReset)
	}
	return &cfg.Servers[len(cfg.Servers)-1]
}

func listServers(cfg *Config) {
	if len(cfg.Servers) == 0 {
		fmt.Printf("%sBelum ada server tersimpan. Jalankan: sshvps --add%s\n", cYel, cReset)
		return
	}
	fmt.Printf("\n%sServer tersimpan:%s\n", cBold, cReset)
	for i, s := range cfg.Servers {
		mark := " "
		if s.AutoConnect {
			mark = "*"
		}
		fmt.Printf("  %s%d) %-18s %s@%s:%d\n", mark, i+1, s.Name, s.User, s.Host, s.Port)
	}
	fmt.Printf("%s  (* = server default)%s\n", cDim, cReset)
}

func pickServer(cfg *Config) *Server {
	listServers(cfg)
	if len(cfg.Servers) == 0 {
		return wizard(cfg)
	}
	fmt.Printf("\n%sPilih nomor (a = tambah baru, q = keluar): %s", cBold, cReset)
	line, _ := stdin.ReadString('\n')
	line = strings.ToLower(strings.TrimSpace(line))
	switch line {
	case "q":
		return nil
	case "a":
		return wizard(cfg)
	}
	n, err := strconv.Atoi(line)
	if err != nil || n < 1 || n > len(cfg.Servers) {
		fmt.Printf("%sPilihan tidak valid.%s\n", cRed, cReset)
		return nil
	}
	return &cfg.Servers[n-1]
}

// ---------- known hosts ----------

func knownHostsPath(cfg *Config) string {
	return filepath.Join(filepath.Dir(cfg.path), "known_hosts.json")
}

func loadKnown(cfg *Config) map[string]string {
	m := map[string]string{}
	b, err := os.ReadFile(knownHostsPath(cfg))
	if err == nil {
		json.Unmarshal(b, &m)
	}
	return m
}

func saveKnown(cfg *Config, m map[string]string) {
	b, _ := json.MarshalIndent(m, "", "  ")
	os.MkdirAll(filepath.Dir(cfg.path), 0o700)
	os.WriteFile(knownHostsPath(cfg), b, 0o600)
}

func hostKeyCallback(cfg *Config) ssh.HostKeyCallback {
	return func(hostname string, remote net.Addr, key ssh.PublicKey) error {
		known := loadKnown(cfg)
		fp := ssh.FingerprintSHA256(key)
		stored, ok := known[hostname]
		if !ok {
			fmt.Printf("%sHost key baru untuk %s%s\n  %s\n", cDim, hostname, cReset, fp)
			known[hostname] = fp
			saveKnown(cfg, known)
			return nil
		}
		if stored != fp {
			fmt.Printf("\n%s%s!! PERINGATAN: host key %s BERUBAH !!%s\n", cBold, cRed, hostname, cReset)
			fmt.Printf("  tersimpan : %s\n  sekarang  : %s\n", stored, fp)
			fmt.Printf("%s  Ini bisa berarti server diganti/reinstall, atau ada yang menyadap.%s\n", cYel, cReset)
			if !yesNo("Tetap lanjut dan simpan key baru?", false) {
				return fmt.Errorf("koneksi dibatalkan karena host key berubah")
			}
			known[hostname] = fp
			saveKnown(cfg, known)
		}
		return nil
	}
}

// ---------- koneksi ----------

func dial(cfg *Config, s *Server) (*ssh.Client, error) {
	pw := decryptSecret(s.Password)
	auths := []ssh.AuthMethod{}

	if s.KeyFile != "" {
		if b, err := os.ReadFile(s.KeyFile); err == nil {
			var signer ssh.Signer
			var err2 error
			if pw != "" {
				signer, err2 = ssh.ParsePrivateKeyWithPassphrase(b, []byte(pw))
				if err2 != nil {
					signer, err2 = ssh.ParsePrivateKey(b)
				}
			} else {
				signer, err2 = ssh.ParsePrivateKey(b)
			}
			if err2 == nil {
				auths = append(auths, ssh.PublicKeys(signer))
			}
		}
	}
	if pw != "" {
		auths = append(auths, ssh.Password(pw))
		auths = append(auths, ssh.KeyboardInteractive(
			func(user, instruction string, questions []string, echos []bool) ([]string, error) {
				ans := make([]string, len(questions))
				for i := range questions {
					ans[i] = pw
				}
				return ans, nil
			}))
	}
	if len(auths) == 0 {
		pw = askPassword(fmt.Sprintf("Password %s@%s: ", s.User, s.Host))
		auths = append(auths, ssh.Password(pw))
	}

	conf := &ssh.ClientConfig{
		User:            s.User,
		Auth:            auths,
		HostKeyCallback: hostKeyCallback(cfg),
		Timeout:         15 * time.Second,
	}
	return ssh.Dial("tcp", s.addr(), conf)
}

func run(cfg *Config, s *Server, oneShot string) int {
	setConsoleTitle(fmt.Sprintf("sshvps — %s@%s", s.User, s.Host))
	fmt.Printf("\n%sMenghubungkan ke %s%s@%s:%d%s ...\n", cDim, cReset+cBold, s.User, s.Host, portOr22(s.Port), cReset)

	var client *ssh.Client
	var err error
	for attempt := 1; attempt <= 3; attempt++ {
		client, err = dial(cfg, s)
		if err == nil {
			break
		}
		fmt.Printf("%sGagal (percobaan %d/3): %v%s\n", cYel, attempt, err, cReset)
		if strings.Contains(strings.ToLower(err.Error()), "unable to authenticate") ||
			strings.Contains(strings.ToLower(err.Error()), "host key") {
			break
		}
		time.Sleep(2 * time.Second)
	}
	if err != nil {
		fmt.Printf("%sTidak bisa konek: %v%s\n", cRed, err, cReset)
		fmt.Printf("%sCek: domain/IP benar? port %d terbuka? password benar?%s\n", cDim, portOr22(s.Port), cReset)
		pause()
		return 1
	}
	defer client.Close()
	fmt.Printf("%s✓ Terhubung ke %s@%s%s\n\n", cGreen, s.User, s.Host, cReset)

	if oneShot != "" {
		sess, err := client.NewSession()
		if err != nil {
			fmt.Println(err)
			return 1
		}
		defer sess.Close()
		sess.Stdout = os.Stdout
		sess.Stderr = os.Stderr
		if err := sess.Run(oneShot); err != nil {
			fmt.Printf("%s%v%s\n", cYel, err, cReset)
			return 1
		}
		return 0
	}

	return shell(cfg, s, client)
}

func portOr22(p int) int {
	if p == 0 {
		return 22
	}
	return p
}

func shell(cfg *Config, s *Server, client *ssh.Client) int {
	sess, err := client.NewSession()
	if err != nil {
		fmt.Printf("%sGagal membuka sesi: %v%s\n", cRed, err, cReset)
		return 1
	}
	defer sess.Close()

	w, h := termSize()
	modes := ssh.TerminalModes{
		ssh.ECHO:          1,
		ssh.ICRNL:         1,
		ssh.TTY_OP_ISPEED: 115200,
		ssh.TTY_OP_OSPEED: 115200,
	}
	term := os.Getenv("TERM")
	if term == "" {
		term = "xterm-256color"
	}
	if err := sess.RequestPty(term, h, w, modes); err != nil {
		fmt.Printf("%sGagal request pty: %v%s\n", cRed, err, cReset)
		return 1
	}

	remoteIn, err := sess.StdinPipe()
	if err != nil {
		return 1
	}
	sess.Stdout = os.Stdout
	sess.Stderr = os.Stderr

	state := makeRaw()
	defer state.restore()

	if err := sess.Shell(); err != nil {
		state.restore()
		fmt.Printf("%sGagal start shell: %v%s\n", cRed, err, cReset)
		return 1
	}

	fmt.Printf("%s[Ctrl+] = menu shortcut perintah]%s\r\n", cDim, cReset)

	shortcuts := s.Shortcuts
	if len(shortcuts) == 0 {
		shortcuts = cfg.Shortcuts
	}

	done := make(chan struct{})

	// pantau perubahan ukuran window
	go func() {
		lw, lh := w, h
		t := time.NewTicker(700 * time.Millisecond)
		defer t.Stop()
		for {
			select {
			case <-done:
				return
			case <-t.C:
				nw, nh := termSize()
				if nw != lw || nh != lh {
					lw, lh = nw, nh
					sess.WindowChange(nh, nw)
				}
			}
		}
	}()

	// baca keyboard -> kirim ke server, sambil menangkap Ctrl+]
	go func() {
		buf := make([]byte, 4096)
		for {
			n, err := os.Stdin.Read(buf)
			if n > 0 {
				chunk := buf[:n]
				if i := indexByte(chunk, 0x1D); i >= 0 { // Ctrl+]
					if i > 0 {
						remoteIn.Write(chunk[:i])
					}
					cmd := shortcutMenu(state, cfg, shortcuts)
					if cmd == "\x00quit" {
						remoteIn.Write([]byte("exit\n"))
						continue
					}
					if cmd != "" {
						remoteIn.Write([]byte(cmd + "\n"))
					}
					if i+1 < len(chunk) {
						remoteIn.Write(chunk[i+1:])
					}
					continue
				}
				if _, werr := remoteIn.Write(chunk); werr != nil {
					return
				}
			}
			if err != nil {
				if err != io.EOF {
					return
				}
				return
			}
		}
	}()

	err = sess.Wait()
	close(done)
	state.restore()
	fmt.Printf("\n%sKoneksi ke %s ditutup.%s\n", cDim, s.label(), cReset)
	if err != nil {
		if _, ok := err.(*ssh.ExitMissingError); ok {
			return 0
		}
	}
	return 0
}

func indexByte(b []byte, c byte) int {
	for i := range b {
		if b[i] == c {
			return i
		}
	}
	return -1
}

// shortcutMenu menampilkan daftar perintah cepat di tengah sesi.
func shortcutMenu(state *consoleState, cfg *Config, shortcuts []string) string {
	state.restore()
	defer func() { *state = *makeRaw() }()

	fmt.Printf("\r\n%s%s── Shortcut perintah ──%s\n", cBold, cCyan, cReset)
	for i, c := range shortcuts {
		fmt.Printf("  %s%d)%s %s\n", cBold, i+1, cReset, c)
	}
	fmt.Printf("  %sa)%s tambah shortcut baru\n", cBold, cReset)
	fmt.Printf("  %sq)%s keluar dari SSH\n", cBold, cReset)
	fmt.Printf("%sPilih (Enter = batal): %s", cBold, cReset)

	line, _ := stdin.ReadString('\n')
	line = strings.TrimSpace(line)
	switch strings.ToLower(line) {
	case "":
		return ""
	case "q":
		return "\x00quit"
	case "a":
		nc := ask("Perintah baru", "")
		if nc != "" {
			cfg.Shortcuts = append(cfg.Shortcuts, nc)
			cfg.save()
			return nc
		}
		return ""
	}
	if n, err := strconv.Atoi(line); err == nil && n >= 1 && n <= len(shortcuts) {
		return shortcuts[n-1]
	}
	// dianggap perintah bebas
	return line
}

var _ = base64.StdEncoding

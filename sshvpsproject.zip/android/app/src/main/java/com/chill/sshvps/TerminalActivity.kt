package com.chill.sshvps

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class TerminalActivity : AppCompatActivity(), SshClient.Listener {

    private lateinit var store: Store
    private lateinit var server: Server
    private var ssh: SshClient? = null
    private val buffer = TerminalBuffer()
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var output: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var statusView: TextView
    private lateinit var dot: View
    private lateinit var chips: LinearLayout

    private var lastCommand = ""
    private var autoScroll = true
    private var pendingRender = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_terminal)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        store = Store(this)
        val s = store.byId(intent.getStringExtra("id"))
        if (s == null) {
            toast("Server tidak ditemukan")
            finish()
            return
        }
        server = s

        output = findViewById(R.id.output)
        scroll = findViewById(R.id.scroll)
        input = findViewById(R.id.input)
        statusView = findViewById(R.id.status)
        dot = findViewById(R.id.dot)
        chips = findViewById(R.id.chips)

        output.textSize = store.fontSize
        findViewById<TextView>(R.id.title).text = server.label
        setStatus("Menyiapkan koneksi…", Color.parseColor("#8B949E"))

        findViewById<ImageButton>(R.id.send).setOnClickListener { sendInput() }
        findViewById<ImageButton>(R.id.paste).setOnClickListener { pasteIntoInput() }
        findViewById<ImageButton>(R.id.copyAll).setOnClickListener { copy(buffer.text(), "Semua output disalin") }
        findViewById<ImageButton>(R.id.more).setOnClickListener { showMenu(it) }

        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { sendInput(); true } else false
        }

        // deteksi user scroll manual -> matikan auto-scroll sementara
        scroll.viewTreeObserver.addOnScrollChangedListener {
            val child = scroll.getChildAt(0) ?: return@addOnScrollChangedListener
            val atBottom = scroll.scrollY + scroll.height >= child.height - 40
            autoScroll = atBottom
        }

        buildKeyRow()
        buildChips()
        connect()
    }

    // ---------- koneksi ----------

    private fun connect() {
        ssh?.disconnect()
        buffer.append("\n[menghubungkan ke ${server.target}]\n")
        render()
        ssh = SshClient(server, File(filesDir, "known_hosts"), this).also { it.connect() }
    }

    override fun onStatus(text: String, state: SshClient.State) {
        ui.post {
            val color = when (state) {
                SshClient.State.CONNECTED -> Color.parseColor("#4CC38A")
                SshClient.State.CONNECTING -> Color.parseColor("#E3B341")
                SshClient.State.DISCONNECTED -> Color.parseColor("#8B949E")
                SshClient.State.ERROR -> Color.parseColor("#F0616D")
            }
            setStatus(text, color)
            if (state == SshClient.State.ERROR || state == SshClient.State.DISCONNECTED) {
                buffer.append("\n[$text]\n")
                render()
                if (state == SshClient.State.ERROR) offerRetry(text)
            }
        }
    }

    override fun onOutput(text: String) {
        buffer.append(text)
        scheduleRender()
    }

    /** Gabungkan render supaya UI tidak dibanjiri saat output deras. */
    private fun scheduleRender() {
        if (pendingRender) return
        pendingRender = true
        ui.postDelayed({ pendingRender = false; render() }, 40)
    }

    private fun render() {
        output.text = buffer.text()
        if (autoScroll) scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun setStatus(text: String, color: Int) {
        statusView.text = text
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
        dot.background = bg
    }

    private fun offerRetry(msg: String) {
        AlertDialog.Builder(this)
            .setTitle("Koneksi gagal")
            .setMessage(msg)
            .setPositiveButton("Coba lagi") { _, _ -> connect() }
            .setNeutralButton("Edit server") { _, _ -> finish() }
            .setNegativeButton("Tutup", null)
            .show()
    }

    // ---------- input ----------

    private fun sendInput() {
        val cmd = input.text.toString()
        if (cmd.isEmpty()) return
        if (ssh?.isConnected != true) {
            toast("Belum terhubung")
            return
        }
        lastCommand = cmd
        ssh?.send(cmd)
        input.setText("")
        autoScroll = true
    }

    private fun runShortcut(cmd: String) {
        if (ssh?.isConnected != true) {
            toast("Belum terhubung")
            return
        }
        lastCommand = cmd
        ssh?.send(cmd)
        autoScroll = true
    }

    private fun pasteIntoInput() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
        if (t.isNullOrEmpty()) {
            toast("Clipboard kosong")
            return
        }
        input.setText(input.text.toString() + t)
        input.setSelection(input.text.length)
    }

    private fun copy(text: String, msg: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("sshvps", text))
        toast(msg)
    }

    // ---------- baris tombol khusus ----------

    private fun buildKeyRow() {
        val row = findViewById<LinearLayout>(R.id.keyRow)
        row.removeAllViews()
        val keys = listOf(
            "Ctrl+C" to byteArrayOf(3),
            "Ctrl+D" to byteArrayOf(4),
            "Ctrl+Z" to byteArrayOf(26),
            "Tab" to byteArrayOf(9),
            "↑" to "\u001B[A".toByteArray(),
            "↓" to "\u001B[B".toByteArray(),
            "ESC" to byteArrayOf(27),
            "Enter" to byteArrayOf(13)
        )
        for ((label, bytes) in keys) {
            row.addView(smallButton(label) {
                if (ssh?.isConnected == true) ssh?.sendRaw(bytes) else toast("Belum terhubung")
                autoScroll = true
            })
        }
    }

    private fun smallButton(label: String, onClick: () -> Unit): View {
        val b = Button(this)
        b.text = label
        b.textSize = 11f
        b.isAllCaps = false
        b.setPadding(dp(12), 0, dp(12), 0)
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = dp(34)
        b.minimumHeight = dp(34)
        b.setTextColor(Color.parseColor("#C9D6E2"))
        b.background = androidx.core.content.ContextCompat.getDrawable(this, R.drawable.chip_bg)
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, dp(34)
        ).apply { marginEnd = dp(6) }
        b.layoutParams = lp
        b.gravity = Gravity.CENTER
        b.setOnClickListener { onClick() }
        return b
    }

    // ---------- shortcut perintah ----------

    private fun buildChips() {
        chips.removeAllViews()
        for (cmd in store.shortcuts) {
            val b = smallButton(cmd) { runShortcut(cmd) } as Button
            b.setOnLongClickListener { editShortcut(cmd); true }
            chips.addView(b)
        }
        chips.addView(smallButton("＋ shortcut") { editShortcut(null) })
    }

    private fun editShortcut(existing: String?) {
        val et = EditText(this).apply {
            setText(existing ?: "")
            hint = "mis. systemctl restart nginx"
            setPadding(dp(20), dp(16), dp(20), dp(8))
        }
        val b = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Shortcut baru" else "Edit shortcut")
            .setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                val v = et.text.toString().trim()
                if (v.isEmpty()) return@setPositiveButton
                val list = store.shortcuts
                if (existing == null) list.add(v) else {
                    val i = list.indexOf(existing)
                    if (i >= 0) list[i] = v else list.add(v)
                }
                store.shortcuts = list
                buildChips()
            }
            .setNegativeButton("Batal", null)
        if (existing != null) {
            b.setNeutralButton("Hapus") { _, _ ->
                val list = store.shortcuts
                list.remove(existing)
                store.shortcuts = list
                buildChips()
            }
        }
        b.show()
    }

    // ---------- menu ----------

    private fun showMenu(anchor: View) {
        val m = PopupMenu(this, anchor)
        m.menu.add("Copy output terakhir")
        m.menu.add("Copy semua output")
        m.menu.add("Bersihkan layar")
        m.menu.add("Sambung ulang")
        m.menu.add("Perbesar teks")
        m.menu.add("Perkecil teks")
        m.menu.add("Reset host key")
        m.menu.add("Putuskan & keluar")
        m.setOnMenuItemClickListener { item ->
            when (item.title.toString()) {
                "Copy output terakhir" ->
                    copy(buffer.textAfterLastPrompt(lastCommand), "Output terakhir disalin")
                "Copy semua output" -> copy(buffer.text(), "Semua output disalin")
                "Bersihkan layar" -> { buffer.clear(); render() }
                "Sambung ulang" -> connect()
                "Perbesar teks" -> changeFont(1f)
                "Perkecil teks" -> changeFont(-1f)
                "Reset host key" -> {
                    File(filesDir, "known_hosts").delete()
                    toast("Host key dihapus, sambung ulang untuk menerima yang baru")
                }
                "Putuskan & keluar" -> finish()
            }
            true
        }
        m.show()
    }

    private fun changeFont(delta: Float) {
        val v = (store.fontSize + delta).coerceIn(9f, 22f)
        store.fontSize = v
        output.textSize = v
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        super.onDestroy()
        ssh?.disconnect()
    }
}

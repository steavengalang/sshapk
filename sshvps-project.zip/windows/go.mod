module sshvps

go 1.23

require golang.org/x/crypto v0.42.0

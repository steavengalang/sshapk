# sshvps (Windows)

Client SSH konsol dengan auto-connect.

Build:

    go mod tidy
    GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -ldflags="-s -w" -o sshvps.exe .

Config: `%APPDATA%\sshvps\config.json` (password dienkripsi DPAPI).
Tekan Ctrl+] saat sesi berjalan untuk menu shortcut perintah.

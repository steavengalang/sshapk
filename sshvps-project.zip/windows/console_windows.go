//go:build windows

package main

import (
	"os"
	"syscall"
	"unsafe"
)

const (
	enableProcessedInput      = 0x0001
	enableLineInput           = 0x0002
	enableEchoInput           = 0x0004
	enableWindowInput         = 0x0008
	enableVirtualTerminalIn   = 0x0200
	enableProcessedOutput     = 0x0001
	enableVirtualTerminalOut  = 0x0004
	disableNewlineAutoReturn  = 0x0008
	stdInputHandle            = -10
	stdOutputHandle           = -11
	codePageUTF8            = 65001
)

var (
	kernel32              = syscall.NewLazyDLL("kernel32.dll")
	procGetConsoleMode    = kernel32.NewProc("GetConsoleMode")
	procSetConsoleMode    = kernel32.NewProc("SetConsoleMode")
	procGetStdHandle      = kernel32.NewProc("GetStdHandle")
	procGetScreenBufInfo  = kernel32.NewProc("GetConsoleScreenBufferInfo")
	procSetConsoleCP      = kernel32.NewProc("SetConsoleCP")
	procSetConsoleOutCP   = kernel32.NewProc("SetConsoleOutputCP")
	procSetConsoleTitle   = kernel32.NewProc("SetConsoleTitleW")
)

type consoleState struct {
	inMode, outMode uint32
	ok              bool
}

func stdHandle(which int) syscall.Handle {
	h, _, _ := procGetStdHandle.Call(uintptr(uint32(which)))
	return syscall.Handle(h)
}

func getMode(h syscall.Handle) (uint32, bool) {
	var m uint32
	r, _, _ := procGetConsoleMode.Call(uintptr(h), uintptr(unsafe.Pointer(&m)))
	return m, r != 0
}

func setMode(h syscall.Handle, m uint32) bool {
	r, _, _ := procSetConsoleMode.Call(uintptr(h), uintptr(m))
	return r != 0
}

func setConsoleTitle(t string) {
	p, err := syscall.UTF16PtrFromString(t)
	if err == nil {
		procSetConsoleTitle.Call(uintptr(unsafe.Pointer(p)))
	}
}

// initConsole menyalakan dukungan UTF-8 + ANSI escape agar tampilan Linux rapi.
func initConsole() {
	procSetConsoleCP.Call(uintptr(codePageUTF8))
	procSetConsoleOutCP.Call(uintptr(codePageUTF8))
	out := stdHandle(stdOutputHandle)
	if m, ok := getMode(out); ok {
		setMode(out, m|enableProcessedOutput|enableVirtualTerminalOut)
	}
}

// makeRaw menyiapkan console untuk sesi interaktif (tanpa echo lokal, kirim tombol apa adanya).
func makeRaw() *consoleState {
	st := &consoleState{}
	in, out := stdHandle(stdInputHandle), stdHandle(stdOutputHandle)
	im, ok1 := getMode(in)
	om, ok2 := getMode(out)
	if !ok1 || !ok2 {
		return st
	}
	st.inMode, st.outMode, st.ok = im, om, true
	setMode(in, (im&^(enableEchoInput|enableLineInput|enableProcessedInput|enableWindowInput))|enableVirtualTerminalIn)
	setMode(out, om|enableProcessedOutput|enableVirtualTerminalOut|disableNewlineAutoReturn)
	return st
}

func (s *consoleState) restore() {
	if s == nil || !s.ok {
		return
	}
	setMode(stdHandle(stdInputHandle), s.inMode)
	setMode(stdHandle(stdOutputHandle), s.outMode)
}

// echoOff mematikan echo sementara (untuk input password).
func echoOff() func() {
	in := stdHandle(stdInputHandle)
	m, ok := getMode(in)
	if !ok {
		return func() {}
	}
	setMode(in, m&^enableEchoInput)
	return func() { setMode(in, m) }
}

type coord struct{ X, Y int16 }
type smallRect struct{ Left, Top, Right, Bottom int16 }
type screenBufferInfo struct {
	Size              coord
	CursorPosition    coord
	Attributes        uint16
	Window            smallRect
	MaximumWindowSize coord
}

func termSize() (w, h int) {
	var info screenBufferInfo
	r, _, _ := procGetScreenBufInfo.Call(uintptr(stdHandle(stdOutputHandle)), uintptr(unsafe.Pointer(&info)))
	if r == 0 {
		return 120, 40
	}
	w = int(info.Window.Right-info.Window.Left) + 1
	h = int(info.Window.Bottom-info.Window.Top) + 1
	if w <= 0 {
		w = 120
	}
	if h <= 0 {
		h = 40
	}
	return
}

func isTerminal() bool {
	_, ok := getMode(stdHandle(stdInputHandle))
	return ok
}

var _ = os.Stdin

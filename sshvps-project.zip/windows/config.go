package main

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

// Server adalah satu entri VPS yang tersimpan.
type Server struct {
	Name        string   `json:"name"`
	Host        string   `json:"host"`
	Port        int      `json:"port"`
	User        string   `json:"user"`
	Password    string   `json:"password,omitempty"` // terenkripsi DPAPI (base64) bila tersedia
	KeyFile     string   `json:"key_file,omitempty"`
	AutoConnect bool     `json:"auto_connect"`
	Shortcuts   []string `json:"shortcuts,omitempty"`
}

func (s Server) addr() string {
	p := s.Port
	if p == 0 {
		p = 22
	}
	return s.Host + ":" + strconv.Itoa(p)
}

func (s Server) label() string {
	if s.Name != "" {
		return s.Name
	}
	return s.User + "@" + s.Host
}

// Config adalah isi file konfigurasi.
type Config struct {
	Servers   []Server `json:"servers"`
	Shortcuts []string `json:"shortcuts"` // shortcut global (dipakai semua server)
	path      string
}

func defaultShortcuts() []string {
	return []string{
		"htop",
		"df -h",
		"free -m",
		"uptime",
		"systemctl status nginx",
		"docker ps",
		"tail -n 50 /var/log/syslog",
	}
}

func configPath() string {
	if p := os.Getenv("SSHVPS_CONFIG"); p != "" {
		return p
	}
	base, err := os.UserConfigDir() // %APPDATA% di Windows
	if err != nil || base == "" {
		if exe, e := os.Executable(); e == nil {
			return filepath.Join(filepath.Dir(exe), "sshvps.json")
		}
		return "sshvps.json"
	}
	return filepath.Join(base, "sshvps", "config.json")
}

func loadConfig() (*Config, error) {
	p := configPath()
	c := &Config{path: p}
	b, err := os.ReadFile(p)
	if errors.Is(err, os.ErrNotExist) {
		c.Shortcuts = defaultShortcuts()
		return c, nil
	}
	if err != nil {
		return c, err
	}
	if err := json.Unmarshal(b, c); err != nil {
		return c, err
	}
	c.path = p
	if len(c.Shortcuts) == 0 {
		c.Shortcuts = defaultShortcuts()
	}
	return c, nil
}

func (c *Config) save() error {
	if err := os.MkdirAll(filepath.Dir(c.path), 0o700); err != nil {
		return err
	}
	b, err := json.MarshalIndent(c, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(c.path, b, 0o600)
}

func (c *Config) find(name string) *Server {
	name = strings.ToLower(strings.TrimSpace(name))
	for i := range c.Servers {
		s := &c.Servers[i]
		if strings.ToLower(s.Name) == name || strings.ToLower(s.label()) == name || strings.ToLower(s.Host) == name {
			return s
		}
	}
	return nil
}

func (c *Config) autoServer() *Server {
	for i := range c.Servers {
		if c.Servers[i].AutoConnect {
			return &c.Servers[i]
		}
	}
	if len(c.Servers) == 1 {
		return &c.Servers[0]
	}
	return nil
}

// parseTarget menerima "root@domain.com", "root@domain.com:2222" atau "domain.com".
func parseTarget(t string) (user, host string, port int) {
	port = 22
	user = "root"
	t = strings.TrimPrefix(strings.TrimSpace(t), "ssh://")
	if i := strings.LastIndex(t, "@"); i >= 0 {
		user = t[:i]
		t = t[i+1:]
	}
	if i := strings.LastIndex(t, ":"); i >= 0 && !strings.Contains(t[i+1:], "]") {
		if p, err := strconv.Atoi(t[i+1:]); err == nil {
			port = p
			t = t[:i]
		}
	}
	host = t
	return
}

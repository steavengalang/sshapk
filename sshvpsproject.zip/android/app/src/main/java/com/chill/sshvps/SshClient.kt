package com.chill.sshvps

import com.jcraft.jsch.ChannelShell
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import com.jcraft.jsch.UIKeyboardInteractive
import com.jcraft.jsch.UserInfo
import java.io.File
import java.io.InputStream
import java.io.OutputStream

/**
 * Koneksi SSH + shell interaktif. Semua operasi jaringan jalan di thread terpisah;
 * callback dikirim balik lewat [Listener] (dipanggil dari background thread).
 */
class SshClient(
    private val server: Server,
    private val knownHostsFile: File,
    private val listener: Listener
) {

    interface Listener {
        fun onStatus(text: String, state: State)
        fun onOutput(text: String)
    }

    enum class State { CONNECTING, CONNECTED, DISCONNECTED, ERROR }

    @Volatile private var session: Session? = null
    @Volatile private var channel: ChannelShell? = null
    private var out: OutputStream? = null
    private var reader: Thread? = null
    @Volatile private var stopping = false

    val isConnected: Boolean get() = channel?.isConnected == true && session?.isConnected == true

    fun connect(cols: Int = 140, rows: Int = 40) {
        Thread {
            try {
                stopping = false
                listener.onStatus("Menghubungkan ke ${server.host}…", State.CONNECTING)

                if (!knownHostsFile.exists()) {
                    knownHostsFile.parentFile?.mkdirs()
                    knownHostsFile.createNewFile()
                }

                val jsch = JSch()
                jsch.setKnownHosts(knownHostsFile.absolutePath)

                val s = jsch.getSession(server.user, server.host, server.port)
                val pw = server.password
                s.setPassword(pw)
                s.setConfig("StrictHostKeyChecking", "ask")
                s.setConfig("PreferredAuthentications", "publickey,keyboard-interactive,password")
                s.userInfo = Auth(pw)
                s.serverAliveInterval = 30_000
                s.serverAliveCountMax = 3
                s.connect(20_000)

                val ch = s.openChannel("shell") as ChannelShell
                ch.setPtyType("xterm-256color", cols, rows, 0, 0)
                ch.setEnv("LANG", "en_US.UTF-8")
                val input: InputStream = ch.inputStream
                out = ch.outputStream
                ch.connect(15_000)

                session = s
                channel = ch
                listener.onStatus("Terhubung — ${server.target}", State.CONNECTED)

                reader = Thread {
                    val buf = ByteArray(8192)
                    try {
                        while (!stopping) {
                            val n = input.read(buf)
                            if (n < 0) break
                            if (n > 0) listener.onOutput(String(buf, 0, n, Charsets.UTF_8))
                        }
                    } catch (e: Exception) {
                        if (!stopping) listener.onOutput("\n[stream error: ${e.message}]\n")
                    }
                    if (!stopping) listener.onStatus("Koneksi terputus", State.DISCONNECTED)
                }.also { it.isDaemon = true; it.start() }

            } catch (e: Exception) {
                listener.onStatus(friendly(e), State.ERROR)
            }
        }.also { it.isDaemon = true }.start()
    }

    private fun friendly(e: Exception): String {
        val m = e.message ?: e.toString()
        return when {
            m.contains("Auth fail", true) || m.contains("auth cancel", true) ->
                "Login gagal — user atau password salah"
            m.contains("UnknownHost", true) || m.contains("No address", true) ->
                "Domain/IP tidak ditemukan"
            m.contains("timeout", true) || m.contains("timed out", true) ->
                "Timeout — server tidak merespons (cek firewall/port)"
            m.contains("refused", true) -> "Koneksi ditolak — port SSH tertutup?"
            m.contains("HostKey", true) || m.contains("reject HostKey", true) ->
                "Host key server berubah! Hapus known_hosts di Pengaturan kalau server memang di-reinstall."
            else -> "Gagal konek: $m"
        }
    }

    /** Kirim perintah + Enter. */
    fun send(cmd: String) = sendRaw((cmd + "\n").toByteArray(Charsets.UTF_8))

    /** Kirim byte mentah (mis. Ctrl+C = 0x03, Tab = 0x09). */
    fun sendRaw(data: ByteArray) {
        try {
            out?.write(data)
            out?.flush()
        } catch (e: Exception) {
            listener.onStatus("Gagal kirim: ${e.message}", State.ERROR)
        }
    }

    fun resize(cols: Int, rows: Int) {
        try {
            channel?.setPtySize(cols, rows, 0, 0)
        } catch (_: Exception) {
        }
    }

    fun disconnect() {
        stopping = true
        try { channel?.disconnect() } catch (_: Exception) {}
        try { session?.disconnect() } catch (_: Exception) {}
        channel = null
        session = null
        out = null
    }

    /** Auto-accept host key baru, tolak kalau host key berubah. */
    private inner class Auth(private val pw: String) : UserInfo, UIKeyboardInteractive {
        override fun getPassphrase(): String? = null
        override fun getPassword(): String = pw
        override fun promptPassword(message: String?) = true
        override fun promptPassphrase(message: String?) = true
        override fun promptYesNo(message: String?): Boolean {
            val m = message ?: return false
            // pesan JSch: "The authenticity of host ... can't be established." -> terima & simpan
            // "WARNING: REMOTE HOST IDENTIFICATION HAS CHANGED" -> tolak
            return !m.contains("CHANGED", ignoreCase = true)
        }
        override fun showMessage(message: String?) {}
        override fun promptKeyboardInteractive(
            destination: String?, name: String?, instruction: String?,
            prompt: Array<String>?, echo: BooleanArray?
        ): Array<String> = Array(prompt?.size ?: 0) { pw }
    }
}

package com.chill.sshvps

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var store: Store
    private lateinit var listView: LinearLayout
    private lateinit var empty: TextView
    private var autoLaunched = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)

        listView = findViewById(R.id.list)
        empty = findViewById(R.id.empty)
        findViewById<ExtendedFloatingActionButton>(R.id.fab).setOnClickListener { editDialog(null) }

        autoLaunched = savedInstanceState?.getBoolean("auto") ?: false

        // auto-connect saat aplikasi dibuka
        if (!autoLaunched && savedInstanceState == null) {
            store.autoServer()?.let {
                autoLaunched = true
                open(it)
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean("auto", autoLaunched)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun open(s: Server) {
        startActivity(Intent(this, TerminalActivity::class.java).putExtra("id", s.id))
    }

    private fun render() {
        val servers = store.servers
        listView.removeAllViews()
        empty.visibility = if (servers.isEmpty()) View.VISIBLE else View.GONE
        findViewById<TextView>(R.id.subtitle).text =
            if (servers.isEmpty()) "Belum ada server" else "${servers.size} server tersimpan"

        val inflater = LayoutInflater.from(this)
        for (s in servers) {
            val row = inflater.inflate(R.layout.item_server, listView, false)
            row.findViewById<TextView>(R.id.name).text = s.label
            row.findViewById<TextView>(R.id.target).text = s.target
            row.findViewById<TextView>(R.id.badge).visibility =
                if (s.autoConnect) View.VISIBLE else View.GONE
            row.setOnClickListener { open(s) }
            row.setOnLongClickListener { actionsDialog(s); true }
            row.findViewById<ImageButton>(R.id.edit).setOnClickListener { editDialog(s) }
            listView.addView(row)
        }
        findViewById<ScrollView>(R.id.scroll).post {
            findViewById<ScrollView>(R.id.scroll).scrollTo(0, 0)
        }
    }

    private fun actionsDialog(s: Server) {
        val items = arrayOf(
            "Konek sekarang",
            if (s.autoConnect) "Batalkan auto-connect" else "Jadikan auto-connect",
            "Edit",
            "Hapus"
        )
        AlertDialog.Builder(this)
            .setTitle(s.label)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> open(s)
                    1 -> {
                        s.autoConnect = !s.autoConnect
                        store.upsert(s)
                        render()
                    }
                    2 -> editDialog(s)
                    3 -> confirmDelete(s)
                }
            }
            .show()
    }

    private fun confirmDelete(s: Server) {
        AlertDialog.Builder(this)
            .setTitle("Hapus ${s.label}?")
            .setMessage("Data server dan password tersimpan akan dihapus dari HP ini.")
            .setPositiveButton("Hapus") { _, _ -> store.delete(s.id); render() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun editDialog(existing: Server?) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_server, null)
        val target = view.findViewById<EditText>(R.id.target)
        val pw = view.findViewById<EditText>(R.id.password)
        val name = view.findViewById<EditText>(R.id.name)
        val auto = view.findViewById<CheckBox>(R.id.auto)
        val showPw = view.findViewById<CheckBox>(R.id.showPw)

        showPw.setOnCheckedChangeListener { _, checked ->
            pw.inputType = if (checked)
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            else
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            pw.setSelection(pw.text.length)
        }

        existing?.let {
            target.setText(it.target)
            pw.setText(it.password)
            name.setText(it.name)
            auto.isChecked = it.autoConnect
        }
        if (existing == null) auto.isChecked = store.servers.isEmpty()

        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Tambah server" else "Edit server")
            .setView(view)
            .setPositiveButton("Simpan") { _, _ ->
                val raw = target.text.toString().trim()
                if (raw.isEmpty()) {
                    toast("Alamat SSH belum diisi")
                    return@setPositiveButton
                }
                val (u, h, p) = Server.parseTarget(raw)
                if (h.isEmpty()) {
                    toast("Alamat SSH tidak valid")
                    return@setPositiveButton
                }
                val s = existing ?: Server()
                s.user = u
                s.host = h
                s.port = p
                s.name = name.text.toString().trim().ifBlank { h }
                s.encPassword = Crypto.encrypt(pw.text.toString())
                s.autoConnect = auto.isChecked
                store.upsert(s)
                render()
                if (existing == null) open(s)
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}

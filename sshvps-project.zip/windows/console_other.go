//go:build !windows

package main

import (
	"os"
	"syscall"
	"unsafe"
)

type termios struct {
	Iflag, Oflag, Cflag, Lflag uint32
	Line                       byte
	Cc                         [32]byte
	Ispeed, Ospeed             uint32
}

type consoleState struct {
	old termios
	ok  bool
}

const (
	tcgets  = 0x5401
	tcsets  = 0x5402
	winsize = 0x5413
)

func ioctlTermios(fd uintptr, req uintptr, t *termios) bool {
	_, _, e := syscall.Syscall(syscall.SYS_IOCTL, fd, req, uintptr(unsafe.Pointer(t)))
	return e == 0
}

func initConsole()             {}
func setConsoleTitle(t string) { os.Stdout.WriteString("\x1b]0;" + t + "\a") }

func makeRaw() *consoleState {
	st := &consoleState{}
	var t termios
	if !ioctlTermios(os.Stdin.Fd(), tcgets, &t) {
		return st
	}
	st.old, st.ok = t, true
	t.Iflag &^= syscall.IXON | syscall.ICRNL | syscall.BRKINT | syscall.INPCK | syscall.ISTRIP
	t.Lflag &^= syscall.ECHO | syscall.ICANON | syscall.ISIG | syscall.IEXTEN
	t.Cc[syscall.VMIN] = 1
	t.Cc[syscall.VTIME] = 0
	ioctlTermios(os.Stdin.Fd(), tcsets, &t)
	return st
}

func (s *consoleState) restore() {
	if s == nil || !s.ok {
		return
	}
	t := s.old
	ioctlTermios(os.Stdin.Fd(), tcsets, &t)
}

func echoOff() func() {
	var t termios
	if !ioctlTermios(os.Stdin.Fd(), tcgets, &t) {
		return func() {}
	}
	old := t
	t.Lflag &^= syscall.ECHO
	ioctlTermios(os.Stdin.Fd(), tcsets, &t)
	return func() { o := old; ioctlTermios(os.Stdin.Fd(), tcsets, &o) }
}

type winSize struct{ Row, Col, X, Y uint16 }

func termSize() (int, int) {
	var ws winSize
	_, _, e := syscall.Syscall(syscall.SYS_IOCTL, os.Stdout.Fd(), winsize, uintptr(unsafe.Pointer(&ws)))
	if e != 0 || ws.Col == 0 {
		return 120, 40
	}
	return int(ws.Col), int(ws.Row)
}

func isTerminal() bool {
	var t termios
	return ioctlTermios(os.Stdin.Fd(), tcgets, &t)
}

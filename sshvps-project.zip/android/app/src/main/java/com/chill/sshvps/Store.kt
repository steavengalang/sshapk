package com.chill.sshvps

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Server(
    var id: String = System.currentTimeMillis().toString(),
    var name: String = "",
    var host: String = "",
    var port: Int = 22,
    var user: String = "root",
    var encPassword: String = "",
    var autoConnect: Boolean = false
) {
    val label: String get() = if (name.isNotBlank()) name else "$user@$host"
    val target: String get() = "$user@$host" + if (port != 22) ":$port" else ""
    val password: String get() = Crypto.decrypt(encPassword)

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("name", name); put("host", host); put("port", port)
        put("user", user); put("pw", encPassword); put("auto", autoConnect)
    }

    companion object {
        fun fromJson(o: JSONObject) = Server(
            id = o.optString("id", System.currentTimeMillis().toString()),
            name = o.optString("name"),
            host = o.optString("host"),
            port = o.optInt("port", 22),
            user = o.optString("user", "root"),
            encPassword = o.optString("pw"),
            autoConnect = o.optBoolean("auto", false)
        )

        /** Menerima "root@domain.com", "root@1.2.3.4:2222", atau "domain.com". */
        fun parseTarget(raw: String): Triple<String, String, Int> {
            var t = raw.trim().removePrefix("ssh://").removePrefix("ssh ")
            var user = "root"
            var port = 22
            val at = t.lastIndexOf('@')
            if (at >= 0) {
                user = t.substring(0, at).trim()
                t = t.substring(at + 1)
            }
            val colon = t.lastIndexOf(':')
            if (colon >= 0) {
                t.substring(colon + 1).toIntOrNull()?.let {
                    port = it
                    t = t.substring(0, colon)
                }
            }
            return Triple(user.ifBlank { "root" }, t.trim(), port)
        }
    }
}

class Store(ctx: Context) {

    private val prefs = ctx.getSharedPreferences("sshvps", Context.MODE_PRIVATE)

    var servers: MutableList<Server>
        get() {
            val arr = JSONArray(prefs.getString("servers", "[]"))
            val out = mutableListOf<Server>()
            for (i in 0 until arr.length()) out.add(Server.fromJson(arr.getJSONObject(i)))
            return out
        }
        set(value) {
            val arr = JSONArray()
            value.forEach { arr.put(it.toJson()) }
            prefs.edit().putString("servers", arr.toString()).apply()
        }

    var shortcuts: MutableList<String>
        get() {
            val s = prefs.getString("shortcuts", null) ?: return defaultShortcuts()
            val arr = JSONArray(s)
            val out = mutableListOf<String>()
            for (i in 0 until arr.length()) out.add(arr.getString(i))
            return out
        }
        set(value) {
            val arr = JSONArray()
            value.forEach { arr.put(it) }
            prefs.edit().putString("shortcuts", arr.toString()).apply()
        }

    /** Font size terminal (sp). */
    var fontSize: Float
        get() = prefs.getFloat("font", 13f)
        set(v) = prefs.edit().putFloat("font", v).apply()

    fun upsert(s: Server) {
        val list = servers
        val i = list.indexOfFirst { it.id == s.id }
        if (s.autoConnect) list.forEach { it.autoConnect = false }
        if (i >= 0) list[i] = s else list.add(s)
        servers = list
    }

    fun delete(id: String) {
        servers = servers.filter { it.id != id }.toMutableList()
    }

    fun byId(id: String?): Server? = servers.firstOrNull { it.id == id }

    fun autoServer(): Server? {
        val list = servers
        return list.firstOrNull { it.autoConnect } ?: list.singleOrNull()
    }

    companion object {
        fun defaultShortcuts() = mutableListOf(
            "df -h",
            "free -m",
            "uptime",
            "docker ps",
            "systemctl status nginx",
            "tail -n 50 /var/log/syslog",
            "apt update && apt upgrade -y",
            "reboot"
        )
    }
}
